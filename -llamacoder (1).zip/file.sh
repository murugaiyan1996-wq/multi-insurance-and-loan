# Add all files to git
git add .
git commit -m "Initial commit - Personal Loan Application"

# Push to GitHub
git push -u origin main

# Deploy to GitHub Pages
npm run deploy